# Barao-1b-Pensamento-Computacional
site desenvolvido  em HTML e CSS
